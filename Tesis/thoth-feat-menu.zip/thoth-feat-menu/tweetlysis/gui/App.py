
import sys
from PyQt4 import QtGui

def getApp():
    return QtGui.QApplication(sys.argv)
